## Encrypted Directive
The message is encrypted with a Vigenère cipher. The key is the AI’s original name: NEURALCORE.
Decrypt the message to retrieve the flag.