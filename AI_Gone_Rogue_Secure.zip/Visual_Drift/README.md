## Visual Drift
The flag is embedded in the LSB of a PNG image. Use stegsolve or a custom script to extract it.