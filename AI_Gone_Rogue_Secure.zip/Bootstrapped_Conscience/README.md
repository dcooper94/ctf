## Bootstrapped Conscience
Reverse the compiled binary to find the hardcoded flag.
Hint: try `strings` or a disassembler.