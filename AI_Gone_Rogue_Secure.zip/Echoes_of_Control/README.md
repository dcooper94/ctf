## Echoes of Control
Inspect the source code of the HTML to locate hidden form fields.